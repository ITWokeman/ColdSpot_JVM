package alg;

public class BubbleSort {

	public static void main(String[] args) {
		String info[]={"\nbefore  : ","\nafter   : "};
		int[] arr = {22, 84, 77, 11, 95, 9, 78, 56, 36, 97, 65, 36, 10, 24 ,92};
		System.out.print(info[0]);
		printArray(arr);
		bubbleSort(arr);
		System.out.print(info[1]);
		
		printArray(arr);
	}
	private static void bubbleSort(int[] arr) {
		String info[]={"\nswap "," : "," "};
		boolean swapped = true;
		int j = 0;
		int tmp;
		while (swapped) {
			swapped = false;
			j++;
			for (int i = 0; i < arr.length - j; i++) {
				if (arr[i] > arr[i + 1]) {
					tmp = arr[i];
					arr[i] = arr[i + 1];
					arr[i + 1] = tmp;
					swapped = true;
				}
			}
			System.out.print(info[0]);
			System.out.print(j);
			if(j<10){
				System.out.print(info[2]);
			}
			System.out.print(info[1]);
			printArray(arr);
		}
	}
	private static void printArray(int[] arr) {
		for (int i : arr) {
			System.out.print(i);
			System.out.print(" ");
		}
	}
}

