package alg;

public class BucketSort {
    private int[] bucket;
    private int[] array;
 
    // size是一个范围
    public BucketSort(int[] array) {
        this.array = array;
        int max = array[0];
        int min = array[0];
        for(int i=0; i<array.length; ++i){
            if(array[i]>max){
                max = array[i];
            }
            if(array[i]<min){
                min = array[i];
            }
        }
        bucket = new int[max-min+1]; //算出需要开辟多少个空间
        
    }
 
    public void sort() {
        for (int i = 0; i < array.length; ++i) {
            bucket[array[i]]++;
        }
    }
 
    // 遍历桶，并得到每个桶中数n，并输出n次该桶下标
    public void print() {
        for (int i = 0; i < bucket.length; i++){
            for (int j = 0; j < bucket[i]; j++){
                System.out.print(i+" ");
            }
        }   
        System.out.println();
    }
    
    public static void main(String[] args) {
        int[] array = new int[]{39,12,5,9,46,85,0}; 
        BucketSort order = new BucketSort(array); 
        System.out.print("before : ");
        for(int a:array){
            System.out.print(a+" ");
        }
        order.sort();
        System.out.print("\nafter  : ");
        order.print();
    }
}
