package dp.decorate;

class Person{
	private String name;

	public void Show(){
		System.out.print("Person "+name);
	}
	
	public void setName(String name){
		this.name=name;
	}
}

class Finery extends Person{
	
	private Person component;

	public void Decorate(Person component){
		this.component=component;
	}

	public void Show(){
		if(component!=null){
			component.Show();
		}
	}
}

class TShirts extends Finery{
	public void Show(){
		System.out.print(" [Big TShirt] ");
		super.Show();
	}
}

class BigTrouser extends Finery{
	public void Show(){
		System.out.print(" [Big Trouser] ");
		super.Show();
	}
}

class Sneakers extends Finery{
	public void Show(){
		System.out.print(" [Sneaker] ");
		super.Show();
	}
}

public class DecorationModeTest{
	public static void main(String[] args) {
		System.out.println();
		Person xc = new Person();
		xc.setName("xiao cai");
		Sneakers pqx = new Sneakers();
		BigTrouser kk = new BigTrouser();
		TShirts dtx = new TShirts();

		pqx.Decorate(xc);
		kk.Decorate(pqx);
		dtx.Decorate(kk);
		dtx.Show();
		System.out.println();
	}
}