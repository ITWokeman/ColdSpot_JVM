
package dp.facade;

//下面这样写很蠢，但是为了演示外观模式，所以这样写了
class Stock1{
	public void Buy(){
		System.out.println("Buy Stock1");
	}

	public void Sell(){
		System.out.println("Sell Stock1");
	}
}

class Stock2{
	public void Buy(){
		System.out.println("Buy Stock2");
	}

	public void Sell(){
		System.out.println("Sell Stock2");
	}
}

class Stock3{
	public void Buy(){
		System.out.println("Buy Stock3");
	}

	public void Sell(){
		System.out.println("Sell Stock3");
	}
}

class Fund{

	private Stock1 stock1;
	private Stock2 stock2;
	private Stock3 stock3;

	public Fund(){
		stock1 = new Stock1();
		stock2 = new Stock2();
		stock3 = new Stock3();
	}

	public void BuyFund(){
		stock1.Buy();
		stock2.Buy();
		stock3.Buy();
	}

	public void SellFund(){
		stock1.Sell();
		stock2.Sell();
		stock3.Sell();
	}

}

public class FacadeModeTest{
	public static void main(String[] args) {
		Fund jijin = new Fund();
		jijin.BuyFund();
		jijin.SellFund();
	}
}