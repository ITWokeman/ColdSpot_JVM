package dp.factory;

interface IFactory{
	Operation CreateOperation();
}

class AddFactory implements IFactory{

	public Operation CreateOperation(){
		return new OperationAdd();
	}
}

class SubFactory implements IFactory{

	public Operation CreateOperation(){
		return new OperationSub();
	}
}

class MulFactory implements IFactory{

	public Operation CreateOperation(){
		return new OperationMul();
	}
}

class DivFactory implements IFactory{

	public Operation CreateOperation(){
		return new OperationDiv();
	}
}

public class FactoryTest{
	public static void main(String[] args) {

		IFactory operFactory = new AddFactory();
		Operation oper = OperationFactory.createOperate("+");
		oper.setNumberA(new Float(-14.0f));
		oper.setNumberB(new Float(215.0f));
		//float及其包装类与String拼接会产生问题
		System.out.print(oper.getNumberA());
		System.out.print(" + ");
		System.out.print(oper.getNumberB());
		System.out.print(" = ");
		System.out.println(oper.GetResult());

		operFactory = new SubFactory();
		oper = OperationFactory.createOperate("-");
		oper.setNumberA(new Float(-16));
		oper.setNumberB(new Float(-35));
		//float及其包装类与String拼接会产生问题
		System.out.print(oper.getNumberA());
		System.out.print(" - ");
		System.out.print(oper.getNumberB());
		System.out.print(" = ");
		System.out.println(oper.GetResult());

		operFactory = new MulFactory();
		oper = OperationFactory.createOperate("*");
		oper.setNumberA(new Float(-58));
		oper.setNumberB(new Float(-31));
		//float及其包装类与String拼接会产生问题
		System.out.print(oper.getNumberA());
		System.out.print(" * ");
		System.out.print(oper.getNumberB());
		System.out.print(" = ");
		System.out.println(oper.GetResult());

		operFactory = new DivFactory();
		oper = OperationFactory.createOperate("/");
		oper.setNumberA(new Float(24));
		oper.setNumberB(new Float(0));
		//float及其包装类与String拼接会产生问题
		System.out.print(oper.getNumberA());
		System.out.print(" / ");
		System.out.print(oper.getNumberB());
		System.out.print(" = ");
		if(oper.GetResult()!=null){
			System.out.println(oper.GetResult());
		}

		oper = OperationFactory.createOperate("/");
		oper.setNumberA(new Float(16));
		oper.setNumberB(new Float(1.8));
		//float及其包装类与String拼接会产生问题
		System.out.print(oper.getNumberA());
		System.out.print(" / ");
		System.out.print(oper.getNumberB());
		System.out.print(" = ");
		if(oper.GetResult()!=null){
			System.out.println(oper.GetResult());
		}




	}
}