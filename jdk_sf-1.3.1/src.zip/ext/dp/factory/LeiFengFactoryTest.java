package dp.factory;

//雷锋
class LeiFeng{
	public void Sweep(){
		System.out.println("Sweeping floar");
	}

	public void Wash(){
		System.out.println("Washing clothes");
	}

	public void BuyRice(){
		System.out.println("Buy Rich");
	}
}

//学雷锋的大学生
class Undergraduate extends LeiFeng{

}

//社区志愿者
class Volunteer extends LeiFeng{

}

//雷锋工厂
interface LeiFengFactory{
	LeiFeng CreateLeiFeng();
}

//学雷锋的大学生工厂
class UndergraduateFactory implements LeiFengFactory{
	public LeiFeng CreateLeiFeng(){
		return new Undergraduate();
	}
}

//社区志愿者工厂
class VolunteerFactory implements LeiFengFactory{
	public LeiFeng CreateLeiFeng(){
		return new Volunteer();
	}
}

public class LeiFengFactoryTest{
	public static void main(String[] args) {
		LeiFengFactory factory = new UndergraduateFactory();
		LeiFeng student = factory.CreateLeiFeng();
		student.BuyRice();
		student.Sweep();
		student.Wash();
	}
}