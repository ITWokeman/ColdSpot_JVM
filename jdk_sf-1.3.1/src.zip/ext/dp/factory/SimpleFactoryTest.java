package dp.factory;

class Operation{
	private Float numberA = 0.0f;
	private Float numberB = 0.0f;

	public void setNumberA(Float numberA){
		this.numberA = numberA;
	}

	public void setNumberB(Float numberB){
		this.numberB = numberB;
	}

	public Float getNumberA(){
		return this.numberA;
	}

	public Float getNumberB(){
		return this.numberB;
	}

	public Float GetResult(){
		Float result = 0.0f;
		return result;
	}
}

class OperationAdd extends Operation{

	public Float GetResult(){
		Float result = 0.0f;
		result = super.getNumberA() + super.getNumberB();
		return result;
	}
}

class OperationSub extends Operation{

	 public Float GetResult(){
	 	Float result = 0.0f;
	 	result = super.getNumberA() - super.getNumberB();
	 	return result;
	 }
}

class OperationMul extends Operation{

	public Float GetResult(){
		Float result = 0.0f;
		result = super.getNumberA() * super.getNumberB();
		return result;
	}
}

class OperationDiv extends Operation{

	public Float GetResult(){
		Float result = 0.0f;
		if(super.getNumberB() == 0){
			System.out.println("Math Error : Div Zero!");
			return null;
		}
		result = super.getNumberA() / super.getNumberB();
		return result;
	}
}

class OperationFactory{
	public static Operation createOperate(String Operate){
		if(Operate.equals("+")){
			return new OperationAdd();
		}else if(Operate.equals("-")){
			return new OperationSub();
		}else if(Operate.equals("*")){
			return new OperationMul();
		}else if(Operate.equals("/")){
			return new OperationDiv();
		}
		return null;
	}
}

public class SimpleFactoryTest{
	public static void main(String[] args) {
		Operation oper = OperationFactory.createOperate("+");
		oper.setNumberA(new Float(146.0f));
		oper.setNumberB(new Float(215.0f));
		//float及其包装类与String拼接会产生问题
		System.out.print(oper.getNumberA());
		System.out.print(" + ");
		System.out.print(oper.getNumberB());
		System.out.print(" = ");
		System.out.println(oper.GetResult());

		oper = OperationFactory.createOperate("-");
		oper.setNumberA(new Float(16));
		oper.setNumberB(new Float(35));
		//float及其包装类与String拼接会产生问题
		System.out.print(oper.getNumberA());
		System.out.print(" - ");
		System.out.print(oper.getNumberB());
		System.out.print(" = ");
		System.out.println(oper.GetResult());

		oper = OperationFactory.createOperate("*");
		oper.setNumberA(new Float(58));
		oper.setNumberB(new Float(315));
		//float及其包装类与String拼接会产生问题
		System.out.print(oper.getNumberA());
		System.out.print(" * ");
		System.out.print(oper.getNumberB());
		System.out.print(" = ");
		System.out.println(oper.GetResult());

		oper = OperationFactory.createOperate("/");
		oper.setNumberA(new Float(16));
		oper.setNumberB(new Float(0));
		//float及其包装类与String拼接会产生问题
		System.out.print(oper.getNumberA());
		System.out.print(" / ");
		System.out.print(oper.getNumberB());
		System.out.print(" = ");
		if(oper.GetResult()!=null){
			System.out.println(oper.GetResult());
		}

		oper = OperationFactory.createOperate("/");
		oper.setNumberA(new Float(16));
		oper.setNumberB(new Float(10));
		//float及其包装类与String拼接会产生问题
		System.out.print(oper.getNumberA());
		System.out.print(" / ");
		System.out.print(oper.getNumberB());
		System.out.print(" = ");
		if(oper.GetResult()!=null){
			System.out.println(oper.GetResult());
		}

	}
}