package dp.observer;

import java.util.*;

//通知者
class Boss {
	private List<Observer> observers = new ArrayList<Observer>();
	private String action;

	public void Attach(Observer observer){
		observers.add(observer);
	}

	public void Detach(Observer observer){
		observers.remove(observer);
	}

	public void Notify(){
		for(int i=0;i<observers.size();++i){
			observers.get(i).Update();
		}
	}

	public void setSubjectState(String value){
		this.action=value;
	}

	public String getSubjectState(){
		return action;
	}
}

abstract class Observer{
	protected String name;
	protected Boss sub;

	public abstract void Update();
}

class StockObserver extends Observer{

	public StockObserver(String name,Boss sub){
		this.name=name;
		this.sub=sub;
	}

	public void Update(){
		System.out.println(sub.getSubjectState()+":"+name+" Stop watching stock market,work continue");
	}
}

class NBAObserver extends Observer{

	public NBAObserver(String name,Boss sub){
		this.name=name;
		this.sub=sub;
	}

	public void Update(){
		System.out.println(sub.getSubjectState()+":"+name+" Stop watching NBA,work continue");
	}
}

public class ObserverTest{
	public static void main(String[] args) {

		Boss huhansan = new Boss();//老板

		//老板走了，都在摸鱼
		StockObserver tongshi0 = new StockObserver("weiguancha",huhansan);
		NBAObserver tongshi1 = new NBAObserver("laoli",huhansan);
		StockObserver tongshi2 = new StockObserver("yiguancha",huhansan);
		NBAObserver tongshi3 = new NBAObserver("laozhang",huhansan);

		//老板来了
		huhansan.setSubjectState("Huhansan is come back");
		huhansan.Attach(tongshi0);
		huhansan.Attach(tongshi1);
		huhansan.Attach(tongshi2);
		huhansan.Attach(tongshi3);

		//一名同事没看见老板
		huhansan.Detach(tongshi3);



		huhansan.Notify();
	}
}