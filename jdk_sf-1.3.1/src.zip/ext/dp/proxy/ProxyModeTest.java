package dp.proxy;

class SchoolGirl{
	private String name;

	public void setName(String name){
		this.name=name;
	}

	public String getName(){
		return name;
	}
}

interface GiveGift{
	abstract void GiveDolls();
	abstract void GiveFlowers();
	abstract void GiveChocolate();
}

class Pursuit implements GiveGift{
	SchoolGirl mm;

	public Pursuit(SchoolGirl mm){
		this.mm=mm;
	}

	public void GiveDolls(){
		System.out.println(mm.getName()+" : Give you doll");
	}

	public void GiveFlowers(){
		System.out.println(mm.getName()+" : Give you flower");
	}

	public void GiveChocolate(){
		System.out.println(mm.getName()+" : Give you chocolate");
	}
}

class Proxy implements GiveGift{
	Pursuit zhuojiayi;

	public Proxy(SchoolGirl mm){
		zhuojiayi = new Pursuit(mm);
	}

	public void GiveDolls(){
		zhuojiayi.GiveDolls();
	}

	public void GiveFlowers(){
		zhuojiayi.GiveFlowers();
	}

	public void GiveChocolate(){
		zhuojiayi.GiveChocolate();
	}
}

public class ProxyModeTest{
	public static void main(String[] args) {
		SchoolGirl jiaojiao = new SchoolGirl();
		jiaojiao.setName("lijiaojiao");

		Proxy daili = new Proxy(jiaojiao);

		daili.GiveDolls();
		daili.GiveFlowers();
		daili.GiveChocolate();
	}
}