package dp.template;

//全国精罗统一考试
class TestPaper{

	private String testName="中华人民共和国精罗统一考试";

	public TestPaper(String name){
		System.out.println("\n"+testName+"\n---"+name+"的 答案\n");
	}

	public void TestQuestion1(){
		System.out.println("问题1 : 罗马帝国灭亡于 ?");
		System.out.println("A.公元476年	B.公元1453年	C.公元1922年	D.公元1917年");
	}

	public void TestQuestion2(){
		System.out.println("问题2 : 罗马帝国的国教是 ?");
		System.out.println("A.多神教	B.天主教	C.东正教	D.伊斯兰教");
	}

	public void TestQuestion3(){
		System.out.println("问题3 :下面哪个城市是罗马帝国首都 ?");
		System.out.println("A.罗马	B.君士坦丁堡	C.伊斯坦布尔		D.莫斯科	E.威尼斯");
	}

}

//学生甲抄的试卷
class TestPaperA extends TestPaper{

	public TestPaperA(String name){
		super(name);
	}

	public void TestQuestion1(){
		super.TestQuestion1();
		System.out.println("回答:B\n");
	}

	public void TestQuestion2(){
		super.TestQuestion2();
		System.out.println("回答:C\n");
	}

	public void TestQuestion3(){
		super.TestQuestion3();
		System.out.println("回答:A\n");
	}
}

//学生乙抄的试卷
class TestPaperB extends TestPaper{

	public TestPaperB(String name){
		super(name);
	}

	public void TestQuestion1(){
		super.TestQuestion1();
		System.out.println("回答:A\n");
	}

	public void TestQuestion2(){
		super.TestQuestion2();
		System.out.println("回答:C\n");
	}

	public void TestQuestion3(){
		super.TestQuestion3();
		System.out.println("回答:D\n");
	}
}

public class TestPaperTest{
	public static void main(String[] args) {
		TestPaperA std1 = new TestPaperA("精罗落泪");
		std1.TestQuestion1();
		std1.TestQuestion2();
		std1.TestQuestion3();

		TestPaperB std2 = new TestPaperB("精罗震怒");
		std2.TestQuestion1();
		std2.TestQuestion2();
		std2.TestQuestion3();

	}
}