package games.minescanner;

import java.util.*;

class Boundary{

	//数值0：没有地雷，没有被扫	数值1~8：没有地雷但是被扫了。数值1~8代表其附近的地雷数量
	//数值9：有雷	数值10：没地雷，被标记	数值11：有地雷，被引爆了	数值19：有地雷，被标记
	//数值-1：没地雷，有被扫
	private int[][] mineField;

	private Scanner scanner = new Scanner(System.in);
	private Mine mine;
	private static String[] symbol = {"","|①|","|②|","|③|","|④|","|⑤|","|⑥|","|⑦|","|⑧|"};
	private int mineNum;

	public Boundary(){
		System.out.print("创建雷区\n输入行数(小于30):");
		int row = this.checker(scanner.nextInt());//行
		System.out.print("输入行数(小于30):");
		int col = this.checker(scanner.nextInt());//列

		System.out.println("创建成功!\n");
		this.mineField = new int[col][row];
		mine = new Mine(mineField);
		mineNum = mine.getMineNum();
		showBoundary(false);
	}

	public void showBoundary(boolean end){
		
		int num = 0;
		for(int i=0;i<mineField.length;++i){
			System.out.print("   +");
			for(int j=0;j<mineField[0].length;++j){
				if(i>0 && ((i<mineField.length-1 && mineField[i-1][j] >= 1 && mineField[i-1][j] <= 8)  
					|| (mineField[i][j] >= 1 && mineField[i][j] <= 8))){
					System.out.print("二二+");
				}else{
					System.out.print("----+");
				}
			}
			System.out.print("\n   |");

			for(int j=0;j<mineField[0].length;++j){
				int mineVal = mineField[i][j];
				if(mineVal == -1){
					System.out.print("    ");
				}else if(mineVal == 0 || (mineVal==9 && end ==false)){
					if(num<10){
						System.out.print("   ");
					}else if(num<100){
						System.out.print("  ");
					}else{
						System.out.print(" ");
					}
					System.out.print(num);
				}else if(mineVal == 9){
					if(end){
						System.out.print(" ● ");
					}else{
						System.out.print("    ");
					}
				}else if(mineVal > 9){//标记
					
					if(end==true){
						if(mineVal==10){
							System.out.print(" X  ");
						}else if(mineVal==11){
							System.out.print(" ○ ");
						}else{
							System.out.print(" √ ");
						}
					}else{
						System.out.print(" ☆ ");
					}
				}else{
					System.out.print(symbol[mineVal]);
				}
				System.out.print("|");

				num++;
			}
			System.out.println();
		}
		System.out.print("   +");
		for(int j=0;j<mineField[0].length;++j){
			System.out.print("----+");
		}
		System.out.println("\n");
	}

	private int checker(int num){
		if(num>30 || num<1){
			System.out.println("[已控制输入限制在1~30]");
			num=30;
		}
		return num;
	}

	public boolean scan(int num){
		if(num>mineField[0].length*mineField.length-1){
			System.out.println("没有这个方格!");
			return true;
		}
		int y = num/mineField[0].length;
		int x = num%mineField[0].length;
		if(mineField[y][x] != 0 && mineField[y][x] != 9){
			System.out.println("这个方格已被标记/扫描过\n");
			return true;
		}
		if(mineField[y][x] == 9){
			System.out.println("你输掉了");
			mineField[y][x] = 11;
			showBoundary(true);
			return false;
		}else if(mine.mineFinder(x,y) == true){
			showBoundary(true);
			return false;
		}
		showBoundary(false);
		return true;
	}

	public void mark(int num){
		if(num>mineField[0].length*mineField.length-1){
			System.out.println("没有这个方格!");
			return;
		}
		int y = num/mineField[0].length;
		int x = num%mineField[0].length;
		int mineVal = mineField[y][x];
		if(mineVal == 19 || mineVal == 10){
			mineField[y][x]-=10;
		}else if(mineVal == 9 || mineVal == 0){
			mineField[y][x]+=10;
		}
		showBoundary(false);
	}

}

class Mine{

	private Random rand = new Random();
	private int mineNum = 0;
	private int scanNum = 0;//被扫描的安全区域
	private int[][] mineField;

	public Mine(int[][] mineField){
		this.mineField = mineField;
		layMines();
	}

	//布雷器
	public void layMines(){
		int col = mineField.length;
		int row = mineField[0].length;
		
		int n = 2*col*row/6;
		for(int i=0;i<n;i+=2){
			int  y = rand.nextInt(col);
			if(y<0){y=-y;}
			int x = rand.nextInt(row);
			if(x<0){x=-x;}
			if(mineField[y][x]==0){
				++mineNum;
			}

			mineField[y][x]=9;
		}
		scanNum = col*row-1-mineNum;
	}

	public int getMineNum(){
		return mineNum;
	}

	int[][] dir1 = {{-1,-1},{-1,0},{-1,1},{0,-1},{0,1},{1,-1},{1,0},{1,1}};
	//扫雷器
	public boolean mineFinder(int x,int y){

		if(scanNum==0){
			System.out.println("\n你赢了\n");
			return true;
		}
		
		if(mineField[y][x] == 0){//没地雷

			int aroundMineNum = aroundMines(x,y);
			if(aroundMineNum == 0){
				mineField[y][x] = -1;
				--scanNum;
				for(int i=0;i<dir1.length;++i){
					int X = dir1[i][1]+x;
					int Y = dir1[i][0]+y;
					if(X>=0 && X<mineField[0].length && Y>=0 && Y<mineField.length){
						mineFinder(X,Y);
					}
				}
			}else{
				mineField[y][x] = aroundMineNum;
				--scanNum;
				return false;
			}
		}
		return false;
	}

	int[][] dir2 = {{-1,-1},{-1,0},{-1,1},{0,-1},{0,1},{1,-1},{1,0},{1,1}};
	//周围地雷
	public int aroundMines(int x,int y){
		
		int mines = 0;
		for(int i=0;i<dir2.length;++i){
			int X = x+dir2[i][1];
			int Y = y+dir2[i][0];
			if(X>=0 && X<mineField[0].length && Y>=0 && Y<mineField.length){
				if(mineField[Y][X]==9 || mineField[Y][X]==19){
					++mines;
				}
			}
		}
		return mines;
	}

}

class Game{

	private Boundary boundary;
	private static Scanner scanner = new Scanner(System.in);

	public Game(){
		boundary = new Boundary();
	}

	public void playGame(){
		while(true){
			System.out.print("输入命令(输入help查看帮助):");
			String input = scanner.next();
			int boundNum = 0,digit=1;
			char[] bn = input.substring(1,input.length()).toCharArray();
			input = input.substring(0,1);
			for(int i=bn.length-1;i>=0;--i){
				boundNum += (bn[i]-'0')*digit;
				digit *= 10;
			}
			if(input.equals("e")){
				break;
			}else if(input.equals("h")){
				help();
			}else if(input.equals("s")){
				if(boundary.scan(boundNum) == false){
					break;
				}
			}else if(input.equals("m")){
				boundary.mark(boundNum);
			}
			//
		}
	}

	private void help(){
		System.out.println("\n咸鱼Java虚拟机扫雷游戏——命令帮助");
		System.out.println("\n操作代码列表\ns[方格编号]:	扫雷[方格编号]\nm[方格编号]:	标记/取消标记[方格编号]\n"
			+"help:		查看帮助\nexit:		退出游戏\n例:m14:标记/取消标记方格14\n");
		System.out.println("界面信息\n12:		12号方格\n●:		地雷\n○:		点击到地雷\n☆:		标记有地雷\n√:		标记的格子有地雷\nX:		标记的地雷没有格子\n");
	}
}

public class MineScanner{
	private static Scanner scanner = new Scanner(System.in);
	public static void main(String[] args) {
		System.out.println("\n******************************\n咸鱼Java虚拟机——扫雷游戏\n******************************");

		while(true){
			Game game = new Game();
			game.playGame();
			System.out.print("输入y开始新游戏:");
			if(!scanner.next().equals("y")){
				break;
			}
			System.out.println("新一轮");
		}
		
	}

}