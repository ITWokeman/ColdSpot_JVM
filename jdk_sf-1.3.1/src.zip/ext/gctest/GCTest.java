package gctest;

class B{
	static String bname = "B Class" ;
	int val;
	B ref;
	String name;
}

class A extends B{

}

//建议内存开5000B以上，太小回收次数过多不便于展示
public class GCTest{
	public static void main(String[] args) {

		//创建4个对象
		A a = new A();
		a.name = new String("Object a");
		a.val = 1000;

		B b1 = new B();
		b1.val = 123;
		b1.name = new String("Object b1");

		B b2 = new B();
		b2.name = new String("Object b988e");
		b2.val=456;

		B b3 = new B();
		b3.name = new String("Object b3");
		b3.val=789;

		//循环引用，测试对象循环引用是否影响垃圾回收
		a.ref = b1;
		b1.ref = b2;
		b2.ref = b3;
		b3.ref = a;

		String c = "hello";

		//制造垃圾，触发GC
		for(int i=0;i<100;++i){
			new A();
		}


		System.out.println(a.ref.val);
		System.out.println(a.ref.name);
		System.out.println(b1.ref.val);
		System.out.println(b1.ref.name);
		System.out.println(b2.ref.val);
		System.out.println(b2.ref.name);
		System.out.println(b3.ref.val);
		System.out.println(b3.ref.name);
		System.out.println(A.bname);
		System.out.println(c);

	}

}