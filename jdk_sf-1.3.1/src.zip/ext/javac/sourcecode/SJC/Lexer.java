package SJC;
import saltedfish.util.*;


public class Lexer {
    public static final int  EOI = 0;//end
    public static final int  SEMI = 1;//分号
    public static final int  PLUS = 2;//加号
    public static final int  TIMES = 3;//乘号
    public static final int  LP = 4;//左括号
    public static final int  RP = 5;//右括号
    public static final int  NUM_OR_ID = 6;//数字或变量符号
    public static final int  UNKNOWN_SYMBOL = 7;//为止符号
    
    private int lookAhead = -1;
    
    public String yytext = "";
    public int yyleng = 0;
    public int yylineno = 0;
    
    private String input_buffer = "";
    private String current = "";
    
    private boolean isAlnum(char c) {
        if((c>='a' && c<='z') || (c>='A' && c<='Z') || (c>='0' && c<='9')){
            return true;
        }
    	
    	return false;
    }
    
    private int lex() {
    
    	while (true) {
    		
    		while (current == "") {
    		    SFScanner s = new SFScanner();
    		    while (true) {
    		    	String line = s.nextLine();
    		    	if (line.equals("end")) {
    		    		break;
    		    	}
    		    	input_buffer += line;
    		    }
    		    
    		    if (input_buffer.length() == 0) {
    		    	current = "";
    		    	return EOI;
    		    }
    		    
    		    current = input_buffer;
    		    ++yylineno;
    		    current.trim();
    		}//while (current == "")
    		
    		if (current.isEmpty()) {
    			return EOI;
    		}
    		    
    		    for (int i = 0; i < current.length(); i++) {
    		    	
    		    	yyleng = 0;
    		    	yytext = current.substring(0, 1);

                    char c = current.charAt(i);
                    if(c==';'){
                        current = current.substring(1); return SEMI;
                    }else if(c=='+'){
                        current = current.substring(1); return PLUS;
                    }else if(c=='*'){
                        current = current.substring(1);return TIMES;
                    }else if(c=='('){
                        current = current.substring(1);return LP;
                    }else if(c==')'){
                        current = current.substring(1);return RP;
                    }else if(c=='\n' || c=='\t' || c==' '){
                        current = current.substring(1);
                    }else{
                        if (isAlnum(current.charAt(i)) == false) {
                            return UNKNOWN_SYMBOL;
                        }
                        else {
                            
                            while (i < current.length() && isAlnum(current.charAt(i))) {
                                i++;
                                yyleng++;
                            } // while (isAlnum(current.charAt(i)))
                            
                            yytext = current.substring(0, yyleng);
                            current = current.substring(yyleng); 
                            return NUM_OR_ID;
                        }
                    } //switch (current.charAt(i))
    		    }//  for (int i = 0; i < current.length(); i++) 
    		
    	}//while (true)	
    }//lex()
    
    public boolean match(int token) {
    	if (lookAhead == -1) {
    		lookAhead = lex();
    	}
    	
    	return token == lookAhead;
    }
    
    public void advance() {
    	lookAhead = lex();
    }
    
    public void runLexer() {
    	while (!match(EOI)) {
    		System.out.println("Token: " + token() + " ,符号: " + yytext );
    		advance();
    	}
    }
    
    private String token() {
    	String token = "";

        if(lookAhead==EOI){
            token = "EOI";
        }else if(lookAhead==PLUS){
            token = "PLUS";
        }else if(lookAhead==TIMES){
            token = "TIMES";
        }else if(lookAhead==NUM_OR_ID){
            token = "NUM_OR_ID";
        }else if(lookAhead==SEMI){
            token = "SEMI";
        }else if(lookAhead==LP){
            token = "LP";
        }else if(lookAhead==RP){
            token = "RP";
        }
    	return token;
    }
}



