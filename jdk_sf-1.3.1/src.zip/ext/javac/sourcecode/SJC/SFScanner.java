package saltedfish.util;

/**
@author 黄峰源
java.util.Scanner类的替代品，用于接收程序输入的内容
**/
public class SFScanner{

	/**
	通过SF虚拟机的本地方法，获取输入的内容（换行符结束）
	**/
	private native String getInputNextLine();

	/**
	通过SF虚拟机的本地方法，获取输入的内容（空格结束）
	**/
	private native String getInputNext();

	/**
	通过SF虚拟机的本地方法，获取输入的int数字（空格结束）
	**/
	private native int getInputNextInt();


	//同java.util.Scanner的nextLine()方法。
	public String nextLine(){
		return getInputNextLine();
	}

	//同java.util.Scanner的next方法
	public String next(){
		return getInputNext();
	}

	//同java.util.Scanner的nextInt方法
	public int nextInt(){
		return getInputNextInt();
	}

}