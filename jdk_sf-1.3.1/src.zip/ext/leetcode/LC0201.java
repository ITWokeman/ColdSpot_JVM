package leetcode;
import java.util.*;

public class LC0201 {
    public static ListNode removeDuplicateNodes(ListNode head) {
        ListNode ob = head;
        while (ob != null) {
            ListNode oc = ob;
            while (oc.next != null) {
                if (oc.next.val == ob.val) {
                    oc.next = oc.next.next;
                } else {
                    oc = oc.next;
                }
            }
            ob = ob.next;
        }
        return head;
    }

    public static void main(String[] args) {
        System.out.println("\n力扣 面试题02.01.移除重复节点");
        System.out.println("\n编写代码，移除未排序链表中的重复节点。保留最开始出现的节点。\n"+
        "示例1:\n输入：[1, 2, 3, 3, 2, 1]\n输出：[1, 2, 3]");

        Scanner s = new Scanner(System.in);
        
        for(int i=0;;++i){
        	System.out.print("\n输入链表长度 : ");

        	int[] arr = new int[s.nextInt()];
        	System.out.print("输入链表元素");
        	for(int j=0;j<arr.length;++j){
        		arr[j] = s.nextInt();
        	}
        	ListNode t = ArrayToLinkList(arr);
        	t = removeDuplicateNodes(t);
            System.out.println("移除的结果是");

            while(t.next!=null){
            	System.out.print(t.val+"->");
            	t = t.next;
            }
            System.out.print(t.val);

            System.out.print("\n输入y继续:");
            if(!s.next().equals("y")){
                break;
            }
        }
    }

    public static ListNode ArrayToLinkList(int[] array){
        ListNode t=new ListNode(array[0]);
        ListNode h=t;
        for(int i=1;i<array.length;++i){
            t.next=new ListNode(array[i]);
            t=t.next;
        }
        return h;
    }
}