package leetcode;

import java.util.*;

public class LC1 {
    public int[] twoSum(int[] nums, int target) {
        Map<Integer,Integer> map = new HashMap<Integer,Integer>();
        for(int i=0;i<nums.length;++i){
            Integer x = map.get(target-nums[i]);
            if(x != null){
                int[] answer = {x,i};
                return answer;
            }else{
                map.put(nums[i],i);
            }
        }
        return null;
    }

    public static void main(String[] arg){
    	Scanner sc = new Scanner(System.in);
    	LC1 lc = new LC1();
    	System.out.println("力扣 1. 两数之和\n给定一个整数数组 nums 和一个目标值 target，请你在该数组中找出和为目标值的那两个整\n"
    		+"数，并返回他们的数组下标。\n\n你可以假设每种输入只会对应一个答案。但是，数组中同一个元素不能使用两遍。\n"
    		+"示例\n给定 nums = [2, 7, 11, 15], target = 9\n\n因为 nums[0] + nums[1] = 2 + 7 = 9\n所以返回 [0, 1]");
    	
    	for (int i=0; ;++i ) {
    		System.out.print("\n输入数组长度:");
    		int[] nums = new int[sc.nextInt()];
    		System.out.print("输入元素:");
    		for(int j=0;j<nums.length;++j){
    			nums[j] = sc.nextInt();
    		}
    		System.out.print("输入目标值:");
    		int target = sc.nextInt();
    		int[] twoSum = lc.twoSum(nums,target);
            if(twoSum==null){
                System.out.println("nums数组没有两个整数和 = "+target+"\n");
            }else{
    		  System.out.println("nums["+twoSum[0]+"] + nums["+twoSum[1]+"] = "+target+"\n");
            }
    		System.out.print("输入y继续:");
    		if(!sc.next().equals("y")){
    			break;
    		}
    	}
    }
}