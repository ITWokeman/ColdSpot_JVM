package leetcode;

public class LC1008{

	private static int[][] test={
		{8,5,1,7,10,12},
	};

    private static TreeNode t;
    private static int p[];
    private static int top=0;
    
    public static TreeNode bstFromPreorder(int[] preorder) {
        
        if(preorder.length==0){return null;}
        
        p=preorder;
        
        t=new TreeNode(p[top++]);
        
        while(top<p.length){
            build(t,p[top]);
            ++top;
        }
        
        return t;
    }
    
    private static void build(TreeNode r,int n){
        if(r.val>n){
            if(r.left!=null){build(r.left,n);}
            else{
                r.left=new TreeNode(n);
            }
        }else{
            if(r.right!=null){build(r.right,n);}
            else{
                r.right=new TreeNode(n);
            }
        }
        
    }

	public static void main(String[] args) {
		System.out.println("\nLeeCode 1008.Construct Binary Search Tree from Preorder Traversal");
		for(int i=0;i<test.length;++i){
			System.out.print("\nTest "+i+"\nPreOrder : ");
			for(int a:test[i]){
				System.out.print(a+" ");
			}
			System.out.print("\nBuild Tree,and postOrder is : ");
			TreeNode t=bstFromPreorder(test[i]);
			postOrder(t);
			System.out.println();
		}
	}
	public static void postOrder(TreeNode t){
		if(t!=null){
			postOrder(t.left);
			postOrder(t.right);
			System.out.print(t.val+" ");
		}
	}
}