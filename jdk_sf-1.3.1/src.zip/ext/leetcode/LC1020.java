package leetcode;

public class LC1020{

	private static int[][][] test={
		{
			{0,0,0,0},
			{1,0,1,0},
			{0,1,1,0},
			{0,0,0,0}
		},
		{
			{0,1,1,0},
			{0,0,1,0},
			{0,0,1,0},
			{0,0,0,0}
		},
		{
			{0,1,1,0,0,0},
			{0,0,0,0,0,1},
			{0,0,1,1,1,0},
			{0,1,0,0,0,0},
			{0,1,0,0,0,0},
			{0,0,1,0,0,0}
		}
	};
    public static void main(String[] args) {

    	System.out.println("\nLeeCode 1020. Number of Enclaves");

    	for(int i=0;i<test.length;++i){
    		System.out.println("\nTest "+i+"\nMap:");
    		testPrinter(test[i]);
    		System.out.println("Number of Enclaves is "+numEnclaves(test[i]));
    		System.out.println("------------------------------");
    	}
    	
    }

    private static void testPrinter(int[][] A){
    	for(int[] a : A){
    		for(int b : a){
    			System.out.print(b+" ");
    		}
    		System.out.println();
    	}
    }

    public static int numEnclaves(int[][] A) {
        if(A==null || A.length==0 ||A[0].length==0)return 0;
        int row=A.length;
        int col=A[0].length;
        for(int i=0;i<row;i++){
            if(A[i][0]==1) dfs(A,i,0);
            if(A[i][col-1]==1)dfs(A,i,col-1);
        }
        for(int i=1;i<col-1;i++){
            if(A[0][i]==1)dfs(A,0,i);
            if(A[row-1][i]==1)dfs(A,row-1,i);
        } 
        int sum=0; 
        for(int i=0;i<row;i++){
            for(int j=0;j<col;j++){
                sum+=A[i][j];
            }
        }
        return sum;
    }
    private static void dfs(int[][] A,int i,int j){
         A[i][j]=0;
         if(i>0 && A[i-1][j]==1) dfs(A,i-1,j);
         if(i<A.length-1 && A[i+1][j]==1)dfs(A,i+1,j);
         if(j>0 && A[i][j-1]==1)dfs(A,i,j-1);
         if(j<A[0].length-1 && A[i][j+1]==1)dfs(A,i,j+1);
    }

}