package leetcode;

public class LC105{
	static int[] preorder = {3,9,20,15,7};
	static int[] inorder = {9,3,15,20,7};

    public static TreeNode build(int []pre,int []in){
        TreeNode root=new TreeNode(pre[0]);
        int i=0,end=in.length-1;
        while(in[i]!=pre[0]){++i;}
            
        if(i>1){
            int LIn[]=new int[i];int LPre[]=new int[i];
            for(int j=0;j<i;++j){LIn[j]=in[j];LPre[j]=pre[j+1];}
            root.left=build(LPre,LIn);
        }else{if(i==1){root.left=new TreeNode(in[0]);}}
            
        if(end-i>1){
            int RIn[]=new int[end-i];int RPre[]=new int[end-i];
            for(int j=i+1;j<pre.length;++j){
                RIn[j-i-1]=in[j];RPre[j-i-1]=pre[j];
            }
            root.right=build(RPre,RIn);
        }else{
            if(end-i==1){
                root.right=new TreeNode(in[end]);
            }
        }
        return root;
    }
        
    public static TreeNode buildTree(int[] preorder, int[] inorder) {   
        if(preorder.length==0){return null;}
        return build(preorder,inorder);
    }

	public static void main(String args[]){
		System.out.println("\nLeeCode 105. Construct Binary Tree from Preorder and Inorder Traversal\n");
		showArray("preorder : ",preorder);
		showArray("inorder  : ",inorder);
		TreeNode t=buildTree(preorder,inorder);
		System.out.print("\nbuild Tree,and postorder is :");
		postOrder(t);
		System.out.println();

	}

	public static void showArray(String info,int[] array){
		System.out.print(info);
		for(int i=0;i<array.length;++i){
			System.out.print(array[i]+" ");
		}
		System.out.println();
	}

	public static void postOrder(TreeNode t){
		if(t!=null){
			postOrder(t.left);
			postOrder(t.right);
			System.out.print(t.val+" ");
		}
	}

}