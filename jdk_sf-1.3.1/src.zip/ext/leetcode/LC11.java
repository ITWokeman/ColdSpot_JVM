
package leetcode;

import saltedfish.util.*;
import java.util.*;

public class LC11{

    //双指针
    private static int maxArea(int[] height) {
        int h=0,t=height.length-1;//左指针，右指针
        int max=0;
        while(h!=t){

            //面积=（左右边界距）*min（左边界，右边界）
            int area = (t-h)*Math.min(height[h], height[t]);
            if(area>max){
                max=area;//计算当前面积
            }

            if(height[h]>height[t]){//如果左边界比右边界高
                t--;//移栋右边界向左
            }else{
                h++;//反正移栋左边界向右
            }
        }
        return max;
    }

    public static void main(String[] args) {
    	System.out.println("\n力扣 11. 盛最多水的容器");
        System.out.println("给你 n 个非负整数 a1，a2，...，an，每个数代表坐标中的一个点 (i, ai) 。在坐标内画 n 条垂直\n"
            +"线，垂直线 i 的两个端点分别为 (i, ai) 和 (i, 0)。找出其中的两条线，使得它们与 x 轴共同构成的\n"
            +"容器可以容纳最多的水。\n说明：你不能倾斜容器，且 n 的值至少为 2。");
        System.out.println("\n输入垂线数量 : 9 输入垂线 : 1 8 6 2 5 4 8 3 7 输入能容纳水的最大值 : 49");
        Scanner s = new Scanner(System.in);

    	for(int i=0;;++i){

            System.out.print("\n输入垂线数量 : ");

            int num = s.nextInt();
            int[] test =new int[num];
    		System.out.print("输入垂线 : ");

            for(int j=0;j<num;++j){
                test[j]=s.nextInt();
            }
    		System.out.println("能容纳水的最大值: "+maxArea(test));

            System.out.print("输入y继续:");
            if(!s.next().equals("y")){
                break;
            }
    	}

    }


}