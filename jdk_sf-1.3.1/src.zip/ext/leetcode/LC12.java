package leetcode;

import saltedfish.util.*;
import java.util.*;

public class LC12{

	public static String intToRoman(int num) {
	    int[] nums = {1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
	    String[] romans = {"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};
	    if(num<1|| num>3999){
	        return "";
	    }
	    StringBuilder sb = new StringBuilder();

	    for(int i = 0;i<nums.length;i++){
	        while(num>=nums[i]){
	            sb.append(romans[i]);
	            num = num-nums[i];
	        }
	    }
	    return sb.toString();
	}

    public static void main(String[] args) {
        System.out.println("\n力扣 12.整数转罗马数字");
        System.out.println("\n输入整数(数值 < 4000) : 3124 输出罗马数字 : MMMCXXIV");

        Scanner s = new Scanner(System.in);
        
        for(int i=0;;++i){
        	System.out.print("\n输入整数 : ");
        	int test = s.nextInt();
            System.out.println(test+" 转罗马数字的结果是 "+intToRoman(test));

            System.out.print("输入y继续:");
            if(!s.next().equals("y")){
                break;
            }
        }
    }
}