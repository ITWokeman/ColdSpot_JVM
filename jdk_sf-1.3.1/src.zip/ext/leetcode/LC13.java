package leetcode;

import saltedfish.util.*;
import java.util.*;

public class LC13{

    private static int[] val;

    public static int romanToInt(String s) {
        val=new int[100];
        val['I']=1;val['V']=5;val['X']=10;val['L']=50;
        val['C']=100;val['D']=500;val['M']=1000;

        char a[]=s.toCharArray();
        int total=0;
        for(int i=0;i<a.length-1;++i){
            int b=val[a[i]],c=val[a[i+1]];
            if(b>=c){
                total+=b;
            }else{
                total-=b;
            }
        }
        return total+val[ a[a.length-1] ];
    }

    public static void main(String[] args) {
        System.out.println("\nLeetCode 13.Roman to Integer");
        System.out.println("Input : III Output : 3");
        Scanner s = new Scanner(System.in);
        for(int i=0;;++i){
            System.out.print("\nInput Roman : ");
            String test = s.next();
            System.out.println("Roman "+test+" to Integer:"+romanToInt(test));

            System.out.print("continue?(y/n):");
            if(!s.next().equals("y")){
                break;
            }
        }
    }
}