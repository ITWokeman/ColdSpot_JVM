package leetcode;

import saltedfish.util.*;
import java.util.*;

public class LC14{

    public static String longestCommonPrefix(String[] strs) {
         
        int amount = strs.length;
        if (amount==0) return "";
        int len = strs[0].length();
        for(int i=1;i<amount;i++){
            if(strs[i].length()<len)
                len=strs[i].length();
        }
        String str="";
        for(int i=1;i<=len;i++){
           str=strs[0].substring(0,i);
            for(int j=1;j<amount;j++){
                if(!str.equals(strs[j].substring(0,i)))
                    return str.substring(0,i-1);
            }
        }
        return str;
    }

	public static void main(String[] args) {
		System.out.println("\nLeetCode 14.Longest Common Prefix");
		Scanner s = new Scanner(System.in);
		for(int i=0;;++i){
			System.out.print("\nInput number of strs : ");
			int num = s.nextInt();
			System.out.print("Input strs : ");
			String test[] = new String[num];
			for(int j=0;j<num;++j){
				test[j] = s.next();
			}
			System.out.println("\nLongest Common Prefix : \""+longestCommonPrefix(test)+"\"");
			System.out.print("continue?(y/n) :");
			if(!s.next().equals("y")){
				break;
			}
		}
	}
}