package leetcode;

import saltedfish.util.*;
import java.util.*;

public class LC19{

    public static ListNode removeNthFromEnd(ListNode head, int n) {
        if(head.next==null){
            head=null;
            return head;
        }
        ListNode a=head;//快指针
        ListNode b=head;//慢指针
        int k=1,m=n;
        while(b.next!=null){
            b=b.next;
            if(n>0){
                --n;
            }else{
                a=a.next;
            }
            ++k;
        }
        if(k==m){
            head=head.next;
        }else{
            a.next=a.next.next;
        }
        return head;
    }

    public static void main(String[] args) {

        System.out.println("\nLeetCode 19.Remove Nth Node From End of List");

        Scanner s = new Scanner(System.in);

        for(int i=0;;++i){

            System.out.print("\nInput list length : ");
            int len = s.nextInt();
            int[] list = new int[len];
            System.out.print("\nInput list nodes : ");
            for(int j=0;j<len;++j){
                list[j]=s.nextInt();
            }

            System.out.print("\nInput remove nth node : ");
            int nthNode = s.nextInt();

            ListNode t=ArrayToLinkList(list);
            ListNode h=t;
            t=removeNthFromEnd(t,nthNode);

            System.out.print("\nRemove Nth node "+nthNode+" : ");
            showList(t);
            System.out.print("\ncontinue?(y/n):");

            if(!s.next().equals("y")){
                break;
            }
        }
    }

    public static void showList(ListNode t){
        while(t!=null){
            System.out.print(t.val+" -> ");
            t=t.next;
        }
        System.out.print("NULL");
    }

    public static ListNode ArrayToLinkList(int[] array){
        ListNode t=new ListNode(array[0]);
        ListNode h=t;
        for(int i=1;i<array.length;++i){
            t.next=new ListNode(array[i]);
            t=t.next;
        }
        return h;
    }
}