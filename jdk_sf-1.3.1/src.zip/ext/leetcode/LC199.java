package leetcode;

class LC199 {

    private int deep=-1;
    private MyArrayList<Integer> a = new MyArrayList<Integer>();
    private int k=0;

    private void ordTravel(TreeNode t,int n){
        if(t!=null){
            if(n>deep){
                a.add(t.val);
            }
            ordTravel(t.right,n+1);
            ordTravel(t.left,n+1);
        }else{
            if(n-1>deep){
                deep=n-1;
            }
        }
    }

    private MyArrayList<Integer> rightSideView(TreeNode root) {
        ordTravel(root,0);
        return a;
    }

    /*
    1.test[0]:{3,5,1,6,2,9,8,null,null,7,4}
                          3
                         / \
                      5       1
                     / \     / \
                    6   2   9   8
                       / \
                      7   4

    2.test[1]:{1,2,3,null,5,null,4}
                          1
                         / \
                      2       3
                       \       \
                        5       4     
                                                      
    */       

    private static Integer[][] test = {
            {3,5,1,6,2,9,8,null,null,7,4},
            {1,2,3,null,5,null,4}
        };

    private static String[][] tree={
        {
        "           3",
        "          / \\",
        "       5       1",
        "      / \\     / \\",
        "     6   2   9   8",
        "        / \\",
        "       7   4"
        },
        {
        "      1",
        "     / \\",
        "   2    3",
        "    \\    \\",
        "     5    4"
        }
    };

    public static void main(String[] args) {

        System.out.println("\nLeeCode 199. Binary Tree Right Side View\n");

        for(int i=0;i<test.length;++i){
            System.out.println("Test "+i+" : ");
            for(int j=0;j<tree[i].length;++j){
                System.out.println(tree[i][j]);
            }
            System.out.println();
            TreeNode t = new TreeNode().levelBuilder(test[i]);
            MyArrayList<Integer> nodes = new LC199().rightSideView(t);
            System.out.print("Tree Right Side View : ");
            for(Integer j=0;j<nodes.size();++j){
                System.out.print(nodes.get(j)+" ");
            }
            System.out.println("\n");
        }
    }
}