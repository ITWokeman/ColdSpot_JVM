package leetcode;

import saltedfish.util.*;
import java.util.*;

public class LC20{

    public static boolean isValid(String s) {
        char ch[]=s.toCharArray();
        char st[]=new char[ch.length];
        int top=-1;
        for(int i=0;i<ch.length;++i){
            if(ch[i]=='{' || ch[i]=='[' || ch[i]=='('){st[++top]=ch[i];}
            else{
                if(top==-1){return false;}
                if(ch[i]=='}' && st[top]=='{'){--top;}
                else if(ch[i]==']' && st[top]=='['){--top;}
                else if(ch[i]==')' && st[top]=='('){--top;}
                else{return false;}
            }
        }
        if(top==-1){return true;}return false;
    }

	public static void main(String[] args) {

		System.out.println("\nLeeCode 20. Valid Parentheses");
        System.out.println("Input : {}[)() Output : is no valid\nInput : (){}[] Output : is valid");
        Scanner s = new Scanner(System.in);
		for(int i=0;;++i){
			System.out.print("\nInput : ");
            String str = s.next();
			if(isValid(str)==true){
				System.out.println("is valid!");
			}else{
				System.out.println("is no valid!");
			}
            System.out.print("\ncontinue?(y/n):");

            if(!s.next().equals("y")){
                break;
            }
		}
	}
}