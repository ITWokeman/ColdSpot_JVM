package leetcode;

public class LC200{

	private static char[][][] test={
		{		
			{'1','1','1','1','0'},
			{'1','1','0','1','0'},
			{'1','1','0','0','0'},
			{'0','0','0','0','0'}
		},
		{
			{'1','1','0','0','0'},
			{'1','1','0','0','0'},
			{'0','0','1','0','0'},
			{'0','0','0','1','1'}
		}
	};

	public static int numIslands(char[][] grid) {
        if(grid==null||grid.length==0) return 0;

        int num_islands = 0;
        int row=grid.length, col=grid[0].length;
        for(int i=0; i<row; i++){
            for(int j=0; j<col; j++){
                if(grid[i][j]=='1'){
                    ++num_islands;
                    dfs(grid, i, j);
                }
            }
        }

        return num_islands;
    }
    
    public static void dfs(char[][] grid, int row, int col){
        int nr=grid.length, nc=grid[0].length;

        if(row<0||row>=nr||col<0||col>=nc||grid[row][col]=='0') return;

        grid[row][col]='0';
        dfs(grid, row-1, col);
        dfs(grid, row+1, col);
        dfs(grid, row, col-1);
        dfs(grid, row, col+1);
    }

	public static void main(String[] args) {
		System.out.println("\nLeetCode 200.Number of Islands\n'1':island\n'0':water");
		for(int i=0;i<test.length;++i){
			System.out.println("\nTest "+i+"\nMap");
			for(char[] a:test[i]){
				for(char b:a){
					System.out.print(b+" ");
				}
				System.out.println();
			}
			System.out.println("Number of Islands : "+numIslands(test[i]));
		}
	}

}