package leetcode;

import saltedfish.util.*;
import java.util.*;
import leetcode.*;

public class LC206{

    public static ListNode reverseList(ListNode head) {
        ListNode t=head;
        ListNode p=head;
        if(head==null || head.next==null){
            return head;
        }
        while(head.next!=null){
            t=head.next;
            head.next=head.next.next;
            t.next=p;
            p=t;
        }
        head=p;
        return head;
    }

    public static void main(String[] args) {

        System.out.println("\n力扣 206.反转链表\n反转一个单链表。");
        Scanner s = new Scanner(System.in);

        for(int i=0;;++i){
            System.out.print("\n输入链表长度:");
            int len = s.nextInt();
            int[] test = new int[len];
            System.out.print("输入链表内容:");
            for(int j=0;j<len;++j){
                test[j] = s.nextInt();
            }

            ListNode t=ArrayToLinkList(test);

            t=reverseList(t);

            System.out.print("反转链表后 : ");
            showList(t);
            System.out.println();

            System.out.print("输入y继续:");
            if(!s.next().equals("y")){
                break;
            }
        }
    }

    public static ListNode ArrayToLinkList(int[] array){
        ListNode t=new ListNode(array[0]);
        ListNode h=t;
        for(int i=1;i<array.length;++i){
            t.next=new ListNode(array[i]);
            t=t.next;
        }
        return h;
    }

    public static void showList(ListNode t){
        while(t!=null){
            System.out.print(t.val+"->");
            t=t.next;
        }
        System.out.print("NULL");
    }
}