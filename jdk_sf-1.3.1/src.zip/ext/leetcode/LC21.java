package leetcode;

import leetcode.*;

public class LC21{

    private static int[][][] test={
        {
            {1,2,4},{1,3,4}
        },
        {
            {1,1,2},{3,4,4}
        },
        {
            {1,4,5,9},{2,3,4}
        }
    };

    
    public static ListNode mergeTwoLists(ListNode l1, ListNode l2) {
        if(l1 == null && l2 == null)
            return null;
        if(l1 == null)
            return l2;
        if(l2 == null)
            return l1;
        ListNode head = null;
        if(l1.val > l2.val){
            head = l2;
            head.next = mergeTwoLists(l1, l2.next);
        }else{
            head = l1;
            head.next = mergeTwoLists(l1.next, l2);
        }
        return head;
    }
    
    public static void main(String[] args) {
        System.out.println("\nLeetCode 21.Merge Two Sorted Lists");
        for(int i=0;i<test[i].length;++i){
            ListNode l1=ArrayToLinkList(test[i][0]);
            ListNode l2=ArrayToLinkList(test[i][1]);
            System.out.println("\nTest "+i);
            System.out.print("list1 : ");
            showList(l1);
            System.out.print("list2 : ");
            showList(l2);
            ListNode l3=mergeTwoLists(l1,l2);
            System.out.print("After merge : ");
            showList(l3);
        }
    }

    public static ListNode ArrayToLinkList(int[] array){
        ListNode t=new ListNode(array[0]);
        ListNode h=t;
        for(int i=1;i<array.length;++i){
            t.next=new ListNode(array[i]);
            t=t.next;
        }
        return h;
    }

    public static void showList(ListNode t){
        while(t!=null){
            System.out.print(t.val+" -> ");
            t=t.next;
        }
        System.out.println("NULL");
    }
}