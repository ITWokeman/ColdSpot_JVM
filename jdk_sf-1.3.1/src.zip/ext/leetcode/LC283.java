
package leetcode;

public class LC283{
	public static void moveZeroes(int[] nums) {
        if(nums == null || nums.length == 0){
            return ;
        }
        int zeroNums = 0;
        for(int i = 0;i < nums.length;i++) {
            if(nums[i] == 0){
                zeroNums++;
            }else{
                nums[i-zeroNums] = nums[i];
            }
        }
        for(int i = 0;i < zeroNums;i++){
            nums[nums.length-1-i] = 0;
        }
    }

    private static int[][] test={
    	{0,1,0,3,12},
    	{0,0,0},
    	{1,4,6,0,4,9}
    };

    public static void main(String[] args) {
    	System.out.println("\nLeeCode 283. Move Zeroes");
    	for(int i=0;i<test.length;++i){
    		System.out.println("\nTest "+i+": ");
    		System.out.print("before remove Zeroes/Zero : ");
    		for(int n:test[i]){
    			System.out.print(n+" ");
    		}
    		System.out.print("\nafter remove Zeroes/Zero  : ");
    		moveZeroes(test[i]);
    		for(int n:test[i]){
    			System.out.print(n+" ");
    		}
    		System.out.println();
    	}

    }


}