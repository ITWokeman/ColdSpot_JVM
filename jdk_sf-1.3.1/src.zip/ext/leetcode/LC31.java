
package leetcode;

import saltedfish.util.*;
import java.util.*;

public class LC31{

    private static int[] values;
    private static int temp;

    private static void swap(int x,int y){
        temp = values[x];
        values[x] = values[y];
        values[y] = temp;
    }
    public static void nextPermutation(int[] nums) {
        int index = nums.length-1;
        values = nums;

        //例子:1 2,8,9,5,4,3,2,1

        //1.查找置换边界index,确保index及其右边的元素是递减的
        //例子中的边界为nums[3]
        while(index >=1 && nums[index-1]>=nums[index]){
            index--;
        }

        //2.如果边界index左边有数字,找到将边界及其右边第一个大于nums[index-1]的元素,将这个元素与nums[index-1]交换
        //由于index及其右边是递减的，所以可以从左往右找第一个
        //例子nums[index-1] = 8,index及其右边第一个大于8的元素为nums[3],交换得:1 2,9,8,5,4,3,2,1
        if(index>0){
            for(int i=nums.length-1;i>=index;--i){
                if(nums[i]>nums[index-1]){
                    swap(index-1,i);
                    break;
                }
            }
        }
        

        //3.如果边界右边有元素,则将nums[index]~nums[nums.length-1]从降序变为升序。
        if(index+1<nums.length){

        	//(1).先将边界右边的元素nums[index+1]~nums[nums.length-1]从降序变为升序。
        	//因为这个区域的元素肯定是递减的,nums[i]与nums[nums.length-1-i]交换即可(index<i<nums.length)
        	//处理得:1 2,9,8,1,2,3,4,5
            for(int i=index+1,j=nums.length-1;i<j;++i,--j){
                swap(i,j);
            }

            //(2).将nums[index]与其右边各元素进行比较,插入相应的位置,使得nums[index]~nums[nums.length-1]变为升序
            //处理得最终结果:1 2,9,1,2,3,4,5,8
            for(int i=index;i<nums.length-1;++i){
                if(nums[i]>nums[i+1]){
                    swap(i,i+1);
                }else{
                    break;
                }
            }
        }
        
    }

    public static void main(String[] args) {
    	System.out.println("\n力扣 31. 下一个排列");
        System.out.println("实现获取下一个排列的函数，算法需要将给定数字序列重新排列成字典序中下一个更大的排列。\n"+
        	"如果不存在下一个更大的排列，则将数字重新排列成最小的排列（即升序排列）。\n必须原地修改，只允许使用额外常数空间。"+
        	"以下是一些例子，输入位于左侧列，其相应输出位于右侧列。\n1,2,3 → 1,3,2\n3,2,1 → 1,2,3\n1,1,5 → 1,5,1");

        Scanner s = new Scanner(System.in);

    	for(int i=0;;++i){

            System.out.print("\n输入数字 : ");
            Integer num = s.nextInt();
            char[] numVal = num.toString().toCharArray();

            int[] test =new int[numVal.length];
            for(int j=0;j<test.length;++j){
                test[j] = numVal[j] - '0';
            }
            nextPermutation(test);
    		System.out.print("下一个排序: ");
    		for (int a:test) {
    			System.out.print(a);
    		}

            System.out.print("\n输入y继续:");
            if(!s.next().equals("y")){
                break;
            }
    	}

    }


}