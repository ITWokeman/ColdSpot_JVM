package leetcode;
import saltedfish.util.*;

public class LC344{

    public static void reverseString(char[] s) {
        char temp;
        for(int i=0;i<s.length/2;i++){
            temp = s[i];
            s[i] = s[s.length-i-1];
            s[s.length-i-1] = temp;
        }
    }

	public static void main(String[] args) {
		System.out.println("\nLeetCode 344.Reverse String");
		SFScanner s = new SFScanner();
		for(int i=0;;++i){
			System.out.print("\nInput String : ");
			String input = s.nextLine();
			char[] test = input.toCharArray();
			System.out.print("Reverse: ");
			reverseString(test);
			for(char a:test){
				System.out.print(a);
			}
			System.out.println("\n");
			System.out.print("continue?(y/n):");
			if(!s.next().equals("y")){
				break;
			}
		}
	}
}