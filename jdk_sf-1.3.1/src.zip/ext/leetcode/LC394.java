package leetcode;

import saltedfish.util.*;
import java.util.*;

public class LC394{

    private static StringBuilder charStack = new StringBuilder();
    private static int[] startStack;
    private static int startTop;
    private static int[] timeStack; 
    private static int timeTop;
    
    private static int index;
    private static char[] chars;
    
    public static String decodeString(String s) {
    	
    	charStack = new StringBuilder();
    	startTop = 0;
    	timeTop = 0;
    	index = 0;
    	timeStack = new int[s.length()];
    	startStack = new int[s.length()];
    	
    	chars = s.toCharArray();
    	int len = chars.length;
    	char nowChar;
    	while(index<len){
    		nowChar = chars[index];
    		if(nowChar>='0' && nowChar<='9'){
    			timeStack[timeTop++] = decodeNum();
    			startStack[startTop++] = charStack.length();
    		}else if((nowChar>='a' && nowChar<='z') || (nowChar>='A' && nowChar<='Z')){
    			charStack.append(nowChar);
    		}else if(nowChar==']'){
    			Integer start = startStack[--timeTop];
    			Integer time = timeStack[--startTop]-1;
    			String str = charStack.substring(start);
    			for(int i=0;i<time;++i){
    				charStack.append(str);
    			}
    		}
    		index++;
    	}
        return charStack.toString();
    }
    
    private static int decodeNum(){
    	int start = index;
    	while(chars[index]>='0' && chars[index]<='9'){
    		index++;
    	}
    	int num = 0;
    	int digit = 1;
    	for(int i=index-1;i>=start;--i){
    		num += (chars[i]-'0')*digit;
    		digit*=10;
    	}
    	return num;
    }

    public static void main(String[] args) {
        System.out.println("\n力扣 394.字符串解码");
        System.out.println("给定一个经过编码的字符串，返回它解码后的字符串。");
        System.out.println("编码规则为: k[encoded_string]，表示其中方括号内部的 encoded_string 正好重复 k 次。注\n意 k 保证为正整数。");
        System.out.println("你可以认为输入字符串总是有效的；输入字符串中没有额外的空格，且输入的方括号总是符合格\n式要求的。");
		System.out.println("此外，你可以认为原始数据不包含数字，所有的数字只表示重复的次数 k ，例如不会出现像 3a 或 2[4] 的输入。");
        System.out.print("\n输入格式为 k[Str],比如 3[a2[c]],2[abc]3[cd]ef");
        System.out.println("\n输入 3[a2[c]] 输出 accaccacc\n输入 2[abc]3[cd]ef输出:abcabccdcdcdef");

		Scanner s = new Scanner(System.in);
       	
        for(int i=0;;++i){
            System.out.print("\n输入字符串 : ");
            String test = s.nextLine();
            System.out.println("解码的字符串 : "+decodeString(test));
            System.out.print("输入y继续:");
            if(!s.next().equals("y")){
                break;
            }
        }

    }
}