
package leetcode;

import saltedfish.util.*;
import java.util.*;

public class LC402{

    public static String removeKdigits(String num, int k) {
        if(num.length()<=k) return "0";
        char[] chars = num.toCharArray();
        char[] minNum= new char[chars.length+1];
        int top = 0;
        int len = chars.length;
        minNum[top++] = '0';
        for(int i=0;i<len;++i){
        	char c = chars[i];
        	while(minNum[top-1]>c && k>0){
        		top--;k--;
        	}
        	minNum[top++] = c;   	
        }
        if(top>k) top-=k;
        int index=0;
        while(index<minNum.length && minNum[index++]=='0');
        if(index-1==top) return "0";
        return new String(minNum).substring(index-1,top);
    }

    public static void main(String[] args) {
    	System.out.println("\n力扣 402. 移掉K位数字");
        System.out.println("给定一个以字符串表示的非负整数 num，移除这个数中的 k 位数字，使得剩下的数字最小。\n示例 1 :"+
        	"输入: num = \"1432219\", k = 3\n输出: \"1219\"\n解释: 移除掉三个数字 4, 3, 和 2 形成一个新的最小的数字 1219。");
        Scanner s = new Scanner(System.in);

    	for(int i=0;;++i){
            System.out.print("\n整数num和k位数字 : ");
    		System.out.println("最小数字: "+removeKdigits(s.next(),s.nextInt()));
            System.out.print("输入y继续:");
            if(!s.next().equals("y")){
                break;
            }
    	}

    }


}