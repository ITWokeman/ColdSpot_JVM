package leetcode;

import saltedfish.util.*;
import java.util.*;

public class LC48{

    public static void rotate(int[][] matrix) {
        int n = matrix.length;
        for (int i=0; i<n/2;++i) {
            for (int j=i; j<n-1-i;++j) {
                int k = matrix[i][j];
                matrix[i][j] = matrix[n-1-j][i];
                matrix[n-1-j][i] = matrix[n-1-i][n-1-j];
                matrix[n-1-i][n-1-j] = matrix[j][n-1-i];
                matrix[j][n-1-i] = k;
            }
        }
    }

    public static void main(String args[]){
        System.out.println("\nLeeCode 48. Rotate Image");
        Scanner s = new Scanner(System.in);
        int rowNum,colNum;
        for(int i=0;;++i){
            System.out.print("Input image row num and col num:");
            rowNum = s.nextInt();
            colNum = s.nextInt();
            int[][] test = new int[rowNum][colNum];
            for(int j=0;j<rowNum;++j){
            	System.out.print((j+1)+" row : ");
            	for(int k=0;k<colNum;++k){
            		test[j][k] = s.nextInt();
            	}
            }
            System.out.println("\nmatrix:");
            showArray(test);
            rotate(test);
            System.out.println("\nrotate:");
            showArray(test);
            System.out.println("------------------------------");
            System.out.print("continue?(y/n):");
			if(!s.next().equals("y")){
				break;
			}
        }
    }

    public static void showArray(int[][] matrix){
        for(int i=0;i<matrix.length;++i){
            for (int j=0;j<matrix[0].length;++j) {
                if(matrix[i][j]<10){
                    System.out.print(" ");
                }
                System.out.print(matrix[i][j]+" ");
            }
            System.out.println();
        }
    }
}