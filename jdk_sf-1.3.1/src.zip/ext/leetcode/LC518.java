package leetcode;

import saltedfish.util.*;
import java.util.*;

public class LC518{

	public static int change(int amount, int[] coins) {
        int[] dp=new int[amount+1];
        dp[0]=1;
        for(int i=coins.length-1;i>=0;i--){
            for(int j=0;j<amount+1;j++){
                if(j-coins[i]>=0){
                    dp[j]+=dp[j-coins[i]];
                }
            }
        }
        return dp[amount];
    }

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("\n力扣 518.零钱兑换 II");
		System.out.println("给定不同面额的硬币和一个总金额。写出函数来计算可以凑成总金额的硬币组合数。假设每一种面额的硬币有无限个。 \n");
		for(int i=0;;++i){
			System.out.print("\n输入找零总额:");
			int amount = s.nextInt();
			System.out.print("输入硬币种类数量:");
			int[] coins = new int[s.nextInt()];

			System.out.print("输入硬币面额:");
			for(int j=0;j<coins.length;++j){
				coins[j] = s.nextInt();
			}
			System.out.println("共有 "+change(amount,coins)+" 种方式找零");
			System.out.print("输入y继续:");
			if(!s.next().equals("y")){
				break;
			}
		}
	}
}