package leetcode;

class Solution {

}

public class LC529{

 	private static char[][][] test={
		{		
			{'E', 'E', 'E', 'E', 'E'},
 			{'E', 'E', 'M', 'E', 'E'},
 			{'E', 'E', 'M', 'E', 'E'},
 			{'E', 'E', 'E', 'E', 'E'}
 		},
 		{		
			{'M', 'M', 'E'},
 			{'M', 'E', 'M'},
 			{'M', 'E', 'E'},
 			{'E', 'E', 'E'}
 		},
 		{		
			{'M', 'M', 'M'},
 			{'E', 'E', 'E'},
 			{'E', 'E', 'E'},
 			{'E', 'E', 'E'}
 		},
 	};
 	private static int [][] clicks={
 		{3,0},{1,1},{2,1}
 	};

    public static char[][] updateBoard(char[][] board, int[] click) {

        if(board == null || board.length == 0)
            return board;
        int x = click[0], y = click[1];
        if(board[x][y] == 'M'){
            board[x][y] = 'X';
            return board;
        }

        dfs(board, x, y);
        return board;
    }

    private static void dfs(char[][] board, int x, int y) {
        if(x < 0 || y < 0 || x >= board.length || y >= board[0].length || board[x][y] != 'E')
            return;
        int count = 0;
        for(int i = -1 ; i < 2; i++) {
            for(int j = -1; j < 2; j++) {
                if(x + i < 0 || x + i >= board.length || j + y < 0 || y + j >= board[0].length) continue;
                if(board[x + i][y + j] == 'M' || board[x + i][y + j] == 'X') count++;
            }
        }
        if(count == 0) {
            board[x][y] = 'B';
            for(int i = -1 ; i < 2; i++) {
                for(int j = -1; j < 2; j++) {
                    dfs(board, x + i, y + j);
                }
            }
        }else {
            board[x][y] = (char)('0' + count);
        }

    }

 	public static void main(String args[]){
 		System.out.println("\nLeeCode 529. Minesweeper\n");
 		System.out.println("'M' : unrevealed mine");
 		System.out.println("'E' : unrevealed empty square");
 		System.out.println("'X' : revealed mine.");
 		System.out.println("'B' : blank square that has no adjacent (above,below,left,right) mines");
 		System.out.println("'1' to '8' : how many mines are adjacent to this revealed square");

 		for(int i=0;i<test.length;++i){
 			System.out.println("\nTest "+i+"\nMine:");
        	showMineField(test[i]);
 			char[][] board=updateBoard(test[i],clicks[i]);
 			System.out.println("\nClick("+clicks[i][0]+","+clicks[i][1]+"):");
        	showMineField(board);
        	System.out.println("------------");
    	}

 	}

    public static void showMineField(char[][] mine){
        for(int i=0;i<mine.length;++i){
            for (int j=0;j<mine[0].length;++j) {
                System.out.print(mine[i][j]+" ");
            }
            System.out.println();
        }
    }

}