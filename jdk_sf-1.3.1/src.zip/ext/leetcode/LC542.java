package leetcode;

public class LC542{

    private int[][] dir = {{0,-1},{0,1},{-1,0},{1,0}};//上下左右
    private int[][] map;

    private int BFS(int X,int Y){
        //xys[N][0]:第n个节点的x坐标,xys[N][1]:第n个节点的y坐标,xys[N][3]:第n个节点的序号
        MyArrayList<Coordinate> xys = new MyArrayList<Coordinate>();
        xys.add(new Coordinate(0,0,0));
        xys.add(new Coordinate(X,Y,1));
        int i=1;
        while(true){
            Coordinate c = xys.get(i);
            
            if(map[c.y][c.x]==0){return c.num;}
            
            for(int j=0;j<4;++j){
                int x=c.x+dir[j][0];
                int y=c.y+dir[j][1];
                if(x>=0 && x<map[0].length && y>=0 && y<map.length){
                    if(map[y][x]==0){return c.num;}
                    xys.add(new Coordinate(x,y,c.num+1));
                }
            }
            ++i;
        }
    }

    class Coordinate{
        public int x;
        public int y;
        public int num;
        public Coordinate(int x,int y,int num){
            this.x=x;this.y=y;this.num=num;
        }
    }

    public int[][] updateMatrix(int[][] matrix) {
        map = matrix;
        for(int i=0;i<map.length;++i){
            for(int j=0;j<map[0].length;++j){
                if(map[i][j]==1){
                    map[i][j]=BFS(j,i);
                }
            }
        }
        return map;
    }

    private static int[][][] test={
        {
            {0,0,0},
            {0,1,0},
            {1,2,1}
        },
        {
            {1,0,1,1,0,0,1,0,0,1},
            {0,1,1,0,1,0,1,0,1,1},
            {0,0,1,0,1,0,0,1,0,0},
            {1,0,1,0,1,1,1,1,1,1},
            {0,1,0,1,1,0,0,0,0,1},
            {0,0,1,0,1,1,1,0,1,0},
            {0,1,0,1,0,1,0,0,1,1},
            {1,0,0,0,1,1,1,1,0,1},
            {1,1,1,1,1,1,1,0,1,0},
            {1,1,1,1,0,1,0,0,1,1}
        },
    };

    public static void main(String[] args) {
        System.out.println("\nLeetCode 542. 01 Matrix");
        for(int i=0;i<test.length;++i){
            System.out.println("\nTest "+i+"\n01 Matrix:");
            for(int []a:test[i]){
                for(int b:a){
                    System.out.print(b+" ");
                }
                System.out.println();
            }
            new LC542().updateMatrix(test[i]);
            System.out.println("\nDistance of the nearest 0 for each cell:");
            for(int []a:test[i]){
                for(int b:a){
                    System.out.print(b+" ");
                }
                System.out.println();
            }
        }

    }
}