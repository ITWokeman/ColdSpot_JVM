package leetcode;

public class LC605{
	private static int[][] test={
		{1,0,0,0,1},
		{1,0,0,0,1},
		{0,0,1,0,1},
		{0,0,0,0,1},
		{1,0,0,0,0,0,1}
	};

	private static int[] n={1,2,1,2,2};

	public static boolean canPlaceFlowers(int[] flowerbed, int n) {
        int a=0,c;
        for(int i=0;i<flowerbed.length+2;++i){
            c=0;
            if(i>0 && i<flowerbed.length+1){
                c=flowerbed[i-1];
            }
            if(c==0){
                ++a;
            }
            if(c==1){
                if(a>2){
                    n-=(a-1)/2;
                }
                a=0;
            }
        }
        if(a>2){
            n-=(a-1)/2;
        }
        if(n<=0){
            return true;
        }else{
            return false;
        }
    }

	public static void main(String[] args) {
		System.out.println("\nLeeCode 605.Can Place Flowers");
		System.out.println("flowers cannot be planted in adjacent plots\n`0` : empty\n`1` : not empty");

		for(int i=0;i<test.length;++i){
			System.out.println("\nTest "+i);
			System.out.print("flowerbed = { ");
			for(int j=0;j<test[i].length;++j){
				System.out.print(test[i][j]+" ");
			}
			System.out.println("}");
			if(canPlaceFlowers(test[i],n[i])==true){
				System.out.println("can place "+n[i]);
			}else{
				System.out.println("can no place "+n[i]);
			}
		}
	}
}