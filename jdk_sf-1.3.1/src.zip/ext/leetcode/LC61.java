package leetcode;

import leetcode.*;

public class LC61{

    private static int[] kTest={3,2,5,3,1};

    private static int[][] ListTest={
        {4,5,7,3,6,8},
        {2,4,5,1},
        {1,2,3},
        {3},
        {2,5,6}
    };
    
    public static ListNode rotateRight(ListNode head, int k) {
        if(head==null||k==0){
            return head;
        }
        ListNode cursor=head;
        ListNode tail=null;//尾指针
        int length=1;
        while(cursor.next!=null)//循环 得到总长度
        {
            cursor=cursor.next;
            length++;
        }
        int loop=length-(k%length);//得到循环的次数
        tail=cursor;//指向尾结点
        cursor.next=head;//改成循环链表
        cursor=head;//指向头结点
        for(int i=0;i<loop;i++){//开始循环
            cursor=cursor.next;
            tail=tail.next;
        }
        tail.next=null;//改成单链表
        return cursor;//返回当前头
    }

    public static void main(String[] args) {

        System.out.println("\nLeetCode 61.Rotate List");

        for(int i=0;i<ListTest.length;++i){
            ListNode t=ArrayToLinkList(ListTest[i]);
            ListNode h=t;
            System.out.print("\nTest "+i+"\nLinkList : ");
            showList(h);

            t=rotateRight(t,kTest[i]);
            System.out.print("\nAfter  rotate right "+kTest[i]+" : ");
            showList(t);
            System.out.println();
        }
    }

    public static void showList(ListNode t){
        while(t!=null){
            System.out.print(t.val+" ");
            t=t.next;
        }
    }

    public static ListNode ArrayToLinkList(int[] array){
        ListNode t=new ListNode(array[0]);
        ListNode h=t;
        for(int i=1;i<array.length;++i){
            t.next=new ListNode(array[i]);
            t=t.next;
        }
        return h;
    }
}