package leetcode;

public class LC62{

    private static int m=7;

    private static int n=3;

    private static int[][] mn={
        {7,3},{4,3},{2,1},{14,9},{12,1}
    };

    public static int uniquePaths(int m, int n) {
        int dp[][]=new int[m][n];
        for(int i=0;i<m;++i){
            for(int j=0;j<n;++j){
                if(i==0 || j==0){dp[i][j]=1;}else{
                    dp[i][j]=dp[i-1][j]+dp[i][j-1];
                }
            }
        }
        return dp[m-1][n-1];
    }

    public static void main(String[] args) {
        System.out.println("\nLeeCode 62. Unique Paths");
        for(int i=0;i<mn.length;++i){
            System.out.print("\nTest "+i+" width="+mn[i][0]+",height="+mn[i][1]+",and different way=");
            System.out.println(uniquePaths(mn[i][0],mn[i][1]));
        }
    }
}