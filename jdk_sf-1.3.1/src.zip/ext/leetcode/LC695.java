package leetcode;

public class LC695{

    private static int[][][] test={
    	{        
    		{1,0,0,0,1},
        	{0,1,0,1,0},
        	{0,0,1,0,0},
        	{0,1,0,1,0},
        	{1,0,0,0,1},
        },
    	{        
    		{0,0,1,0,0,0,0,1,0,0,0,0,0},
        	{0,0,0,0,0,0,0,1,1,1,0,0,0},
        	{0,1,1,0,1,0,0,0,0,0,0,0,0},
        	{0,1,0,0,1,1,0,0,1,0,1,0,0},
        	{0,1,0,0,1,1,0,0,1,1,1,0,0},
        	{0,0,0,0,0,0,0,0,0,1,1,0,0},
        	{0,0,0,0,0,0,0,1,1,1,0,0,0},
        	{0,0,0,0,0,0,0,1,1,0,0,0,0}
        },
        {        
    		{0,0,1,0},
        	{0,0,0,1},
        	{0,1,1,0},
        	{0,1,0,0},
        }
    };

    private static int h=0;
    private static int dir[][]={{1,0},{0,1},{0,-1},{-1,0}};
    public static int maxAreaOfIsland(int[][] grid) {
        int ares=0;
        int k=grid.length;
        int m=grid[0].length;
        for(int p=0;p<k;++p){
            for(int v=0;v<m;++v){
                if(grid[p][v]==1){
                    grid[p][v]=-1;
                    h=1;
                    DSF(grid,v,p,k,m);
                    if(h>ares){
                        ares=h;
                    }
                }
            }
        }
        return ares;
    }
    
    private static int DSF(int [][]g,int i,int j,int m,int k){
        for(int c=0;c<4;++c){
            int I=i+dir[c][0],J=j+dir[c][1];
            if(I>=0 && J>=0 && I<k && J<m && g[J][I]==1){
                ++h;g[J][I]=-1;
                DSF(g,I,J,m,k);
            }
        }
        return h;
    }

    public static void main(String args[]){

        System.out.println("\nLeeCode 695. Max Area of Island\n`0`:Sea\n`1`:land");
        for(int i=0;i<test.length;++i){
        	System.out.println("\nTest"+i+"\nisland map:");
        	for(int j=0;j<test[i].length;++j){
            	for(int k=0;k<test[i][j].length;++k){
                	System.out.print(test[i][j][k]+" ");
            	}
            	System.out.println();
        	}
        	System.out.println("The max area of island is "+maxAreaOfIsland(test[i]));
    	}
    }
}