package leetcode;

import saltedfish.util.*;
import java.util.*;

public class LC7{

	 public static int reverse(int x) {
	    int sum = 0;
	    while (x != 0) {
	        int result = x % 10;
	        x = x / 10;

	        if (sum > Integer.MAX_VALUE / 10 || sum == Integer.MAX_VALUE / 10 && Integer.MAX_VALUE % 10 > 7) return 0;
	        if (sum < Integer.MIN_VALUE / 10 || sum == Integer.MAX_VALUE / 10 && Integer.MAX_VALUE % 10 < -8) return 0;

	        sum = sum * 10 + result;
	    }
	    return sum;
	}


	public static void main(String[] args) {
		
		System.out.println("\n力扣 7. 整数反转\n给出一个 32 位的有符号整数，你需要将这个整数中每位上的数字进行反转。");
		Scanner s = new Scanner(System.in);

		for(int i=0;;++i){
			
			System.out.print("\n输入数字:");
			int test = s.nextInt();
			System.out.println(test+" 反转后 : "+reverse(test));
			System.out.print("输入y继续:");
			if(!s.next().equals("y")){
				break;
			}
		}
	}
}