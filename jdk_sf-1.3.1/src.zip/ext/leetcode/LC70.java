
package leetcode;

public class LC70{
	public static int climbStairs(int n) {
        int[] dp=new int[n+1];
        dp[0]=1;
        dp[1]=2;
        for(int i=2;i<n;i++){
            dp[i]=dp[i-1]+dp[i-2];
        }
        return dp[n-1];
    }

    private static int[] test={0,3,6,28,108,365};

    public static void main(String[] args) {
    	System.out.println("\nLeetCode 70.Remove Nth Node From End of List\n");
    	for(int i=0;i<test.length;++i){
    		System.out.println("Test "+i+" : climb Num "+test[i]+", distinct way(s) Num is "+climbStairs(test[i]));
    	}
    }
}