package leetcode;

import saltedfish.util.*;
import java.util.*;

public class LC739{

    public static int[] dailyTemperatures(int[] T) {
    	int[] answer = new int[T.length];
    	Val[] vals = new Val[T.length];
    	int top = 0;
    	vals[0] = new Val(T[0],0);
    	for(int i=1;i<T.length;++i){
    		int t = T[i];
    		Val v = new Val(t,i);
    		while(top>=-1){
    			if(top == -1){
    				vals[++top] = v;
    				break;
    			}
    			Val topDay = vals[top];
    			if(T[i]>topDay.temperatures){
    				answer[topDay.day] = i-topDay.day;
    				top--;
    			}else{
    				vals[++top] = v;
    				break;
    			}
    		}
    	}
    	return answer;
    }
    
    static class Val{
    	int temperatures ;//温度
    	int day;//天（下标）
    	public Val(int t,int d){
    		temperatures = t;
    		day = d;
    	}
    }

	public static void main(String[] args) {
		
		boolean tag;
		Scanner s = new Scanner(System.in);
		System.out.println("\n力扣 739.每日温度\n根据每日 气温 列表，请重新生成一个列表，对应位置的输出是需要再等待多久温度才会升高超\n"+
			"过该日的天数。如果之后都不会升高，请在该位置用 0 来代替。\n"+
			"例如，给定一个列表 temperatures = [73, 74, 75, 71, 69, 72, 76, 73]，你的输出应该\n是 [1, 1, 4, 2, 1, 1, 0, 0]。");
		for(int i=0;;++i){
			System.out.print("\n天数:");
			int[] test = new int[s.nextInt()];
			System.out.print("输入气温列表:");
			for (int j = 0;j<test.length ;++j ) {
				test[j] = s.nextInt();
			}
			int[] answer = dailyTemperatures(test);
			System.out.print("输出列表:");
			for(int a:answer){
				System.out.print(a+" ");
			}

			System.out.print("\n输入y继续:");
			if(!s.next().equals("y")){
				break;
			}
		}
	}
}