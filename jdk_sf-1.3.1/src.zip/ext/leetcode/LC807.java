package leetcode;

public class LC807{

    private static int[][]grid={
		{3, 0, 8, 4}, 
		{2, 4, 5, 7},
		{9, 2, 6, 3},
		{0, 3, 1, 0} 
	};

    public static int maxIncreaseKeepingSkyline(int[][] grid) {
        int []row=new int[grid.length];//行
        int []line=new int[grid[0].length];//列;
        for(int i=0;i<grid.length;++i){
            for(int j=0;j<grid[0].length;++j){
                row[i]=Math.max(grid[i][j],row[i]);//行最大
                line[i]=Math.max(grid[j][i],line[i]);//列最大
            }
        }
        int total=0;
        for(int i2=0;i2<grid.length;++i2){
            for(int j2=0;j2<grid.length;++j2){
                total=total+Math.min(row[i2],line[j2])-grid[i2][j2];
            }
        }
        return total;
    }

	public static void main(String args[]){
		System.out.println("\nLeeCode 807. Max Increase to Keep City Skyline\n");
		System.out.println(maxIncreaseKeepingSkyline(grid));
	}
}