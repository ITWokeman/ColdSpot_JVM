package leetcode;

import java.util.*;

public class LCM1713{

 	public int respace(String[] dictionary, String sentence) {
        int n = sentence.length();
        int m = dictionary.length;
        int[] dp = new int[n + 1];
        for (int i = 1; i <= n; i++) {
            dp[i] = dp[i-1];
            for (int j = 0; j < m ; j++) {
                if (i < dictionary[j].length()) continue;
                if (sentence.substring(i - dictionary[j].length(), i).equals(dictionary[j])) {
                    dp[i] = Math.max(dp[i - dictionary[j].length()] + dictionary[j].length(), dp[i]);
                }
            }
        }
        return n - dp[n];
    }

	public static void main(String[] args) {
		
		boolean tag;
		Scanner s = new Scanner(System.in);
		LCM1713 lc = new LCM1713();
		System.out.println("\n力扣 17.13. 恢复空格\n哦，不！你不小心把一个长篇文章中的空格、标点都删掉了，并且大写也弄成了小写。像句子\"I\n"+
			"reset the computer. It still didn’t boot!\"已经变成\n"+
			"了\"iresetthecomputeritstilldidntboot\"。在处理标点符号和大小写之前，你得先把它断成\n"+
			"词语。当然了，你有一本厚厚的词典dictionary，不过，有些词没在词典里。假设文章用\n"+
			"sentence表示，设计一个算法，把文章断开，要求未识别的字符最少，返回未识别的字符数。\n");
		for(int i=0;;++i){
			System.out.print("\n输入文章内容:");
			String sentence = s.nextLine();
			System.out.print("输入字典大小:");
			String[] dictionary = new String[s.nextInt()];
			for(int j=0;j<dictionary.length;++j){

				System.out.print("----输入词语"+(j+1)+":");
				String ss = s.nextLine();
				dictionary[j] = new String(ss);
			}

			System.out.println("\n需要添加"+lc.respace(dictionary,sentence)+"个空格\n");

			System.out.print("输入y继续:");
			if(!s.next().equals("y")){
				break;
			}
		}
	}
}