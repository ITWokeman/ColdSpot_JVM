package leetcode;

@SuppressWarnings("unchecked")
public class MyArrayList<E>{
	private Object elementData[]=new Object[6];
	int size=0;
	
	public E get(int i){
		return (E) elementData[i];
	}
	
	public void add(E val){
		if(size>=elementData.length){
			int newLength=elementData.length*2;
			Object[] newElementData = new Object[newLength];
			for(int i=0;i<elementData.length;++i){
				newElementData[i] = elementData[i];
			}
			elementData=newElementData;
		}
		elementData[size++]=val;
	}

	
	public int size(){
		return size;
	}

	public void set(int i,Object n){
		elementData[i]=n;
	}

	public Object remove(int i){
		Object oldValue = elementData[i];
		elementData[--size]=null;
		return oldValue;
	}
}