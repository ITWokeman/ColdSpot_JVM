package leetcode;

public class TreeNode {
 	public int val;
    public TreeNode left;
    public TreeNode right;
    public TreeNode(int x) { val = x; }
    public TreeNode(){}

    private TreeNode s[];
	private int top;
	private int now;
	
	/*
	[3,5,1,6,2,9,8,null,null,7,4]
			              3
			             / \
			          5       1
		             / \     / \
		            6   2   9   8
		               / \
			          7   4
	 Integer h[]={3,5,1,6,2,9,8,null,null,7,4,1,6,2,9,8,5};
	 TreeNode t=new TreeTestBuilder().TreeBuilder(h);			                    		                    
	*/                   
	public TreeNode levelBuilder(Integer t[]){
		if(t.length==0){return null;}
		s=new TreeNode[t.length];
		top=0;now=0;
		s[now]=new TreeNode(t[0]);
		while(top+1<t.length){
			if(s[now]!=null){
				if(t[top+1]!=null){
					s[top+1]=new TreeNode(t[top+1]);
					s[now].left=s[top+1];
				}
				if(top+2<t.length){	
					if(t[top+2]!=null){
						s[top+2]=new TreeNode(t[top+2]);
						if(top+2<t.length){	
							s[now].right=s[top+2];
						}
					}
				}
				top+=2;
			}
			++now;
		}
		return s[0];
	}
}