package test;

public class ArrayTest{
	public static void main(String arg[]){
		int []arr2={31,23,54,46,234};
		System.out.println();
		for(int i=0;i<arr2.length;++i){
			System.out.print(arr2[i]);
			System.out.print(' ');
		}
		
	}
}