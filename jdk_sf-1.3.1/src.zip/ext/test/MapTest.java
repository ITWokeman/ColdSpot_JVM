
package test;

import java.util.*;

public class MapTest{
	public static void main(String[] args) {
		Map<String,String> greatPeople = new HashMap<String,String>();

		greatPeople.put("William the Conqueror","Duke of Normandy");
		System.out.println("William the Conqueror : "+greatPeople.get("William the Conqueror"));

		greatPeople.put("William the Conqueror","King of England");
		System.out.println("William the Conqueror : "+greatPeople.get("William the Conqueror"));

		greatPeople.put("Gaius Julius Caesar","General of Roma");
		greatPeople.put("Gaius Octavius Augustus","Augustus of Roma");

		System.out.println("Gaius Julius Caesar : "+greatPeople.get("Gaius Julius Caesar")+"\nGaius Octavius Augustus : "+greatPeople.get("Gaius Octavius Augustus"));
		System.out.print("Me : ");
		System.out.println(greatPeople.get("Me"));
	}
}