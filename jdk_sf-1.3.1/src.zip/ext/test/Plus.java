package test;

public class Plus{
	public static void main(String arg[]){
		int g=0;
		for(int i=0;i<1001;++i){
			g+=i;
		}
		System.out.println(g);
	}
}