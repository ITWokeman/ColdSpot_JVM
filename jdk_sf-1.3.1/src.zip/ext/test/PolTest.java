package test;
class A {
    public String show(D obj) {
        return ("A and D");
    }

    public String show(A obj) {
        return ("A and A");
    } 

}

class B extends A{
    public String show(B obj){
        return ("B and B");
    }
    
    public String show(A obj){
        return ("B and A");
    } 
}

class C extends B{

}

class D extends B{

}

public class PolTest {
    public static void main(String[] args) {
        A a1 = new A();
        A a2 = new B();
        B b = new B();
        C c = new C();
        D d = new D();

        System.out.println(a1.show(b));//A and A 不解释
        System.out.println(a1.show(c));//A and A 不解释
        System.out.println(a1.show(d));//A and D 不解释

        /**
        B and A
        继承链：(1)this.show(object) -> (2)super.show(object) -> (3)this.show((super)object) -> (4)super.show(super(object)) 
        
        注：
        假如object类继承superA,superA继承superB,并且superA,superB都没有show(object)
        那么查找顺序为
        object.show(superA) -> superA.show(superA) -> superB.show(superA) -> this.show(superB)
        -> superA.show(superB) -> superB.show(superA)

        一、编译期
        对于a2，声明的类型为A。所以编译的时候先从类A开始找。
        1.this.show(object):        b的类型是B，类A里没有show(B obj),查找失败
        2.super.show(obj):          A的super为Object，Object没有show(B obj),查找失败
        3.this.show(super(obj))：   类B的父类为类A，类A有show(A obj)，最终确定使用方法为show(A obj)

        二、执行期
        但是由于A a2 = new B();a2指向的对象的类型实际为B，所以运行时先从类B开始寻找方法show(A obj)
        类B有show(A obj)，所以输出B and A

        **/
    	System.out.println(a2.show(b));

        /**
        同上
        **/
        System.out.println(a2.show(c));//B and A

        /**
        同上
        **/
        System.out.println(a2.show(d));//A and D

        System.out.println(b.show(b));//B and B 不解释

        /**
        B and B
        b声明为B，所以从B类型开始找
        1.this.show(object):        没有方法为show(C obj),查找失败
        2.super.show(object):       类A没有方法为show(C obj),查找失败
        3.this.show((super)object)  C的父类为B，A。按照继承链的原则先找show(B)。B类有show(B obj),查找成功

        所以输出B and B
        **/
        System.out.println(b.show(c));
        
    	System.out.println(b.show(d)); //A and D 不解释  
    }
}