package test;

public class Reflex{
	public static void main(String[] args) { 

	    String a="\n";
	 	a+=Object.class.getName()+"\n"; // java.lang.Object      
	 	a+=Object[].class.getName()+"\n"; // [Ljava.lang.Object;      
	 	a+=Object[][].class.getName()+"\n"; // [[Ljava.lang.Object;   
	 	a+=int[].class.getName()+"\n"; // [I 		    
	  	a+=void.class.getName()+"\n"; // void      
	 	a+=boolean.class.getName()+"\n"; // boolean      
	 	a+=byte.class.getName()+"\n"; // byte      
		a+=char.class.getName()+"\n"; // char      
	 	a+=short.class.getName()+"\n"; // short      
	 	a+=int.class.getName()+"\n"; // int      
	 	a+=long.class.getName()+"\n"; // long      
		a+=float.class.getName()+"\n"; // float      
		a+=double.class.getName()+"\n"; // double      
	 	a+=Object.class.getName()+"\n"; // java.lang.Object      
	 	a+=int[].class.getName()+"\n"; // [I      
	 	a+=int[][].class.getName()+"\n"; // [[I      
	 	a+=Object[].class.getName()+"\n"; // [Ljava.lang.Object;      
	 	a+=Object[][].class.getName()+"\n"; // [[Ljava.lang.Object;      
	 	a+=Runnable.class.getName()+"\n"; // java.lang.Runnable      
	 	a+="abc".getClass().getName()+"\n"; // java.lang.String      
		a+=new double[0][0].getClass().getName()+"\n"; // [D      
	 	a+=new String[0][0].getClass().getName()+"\n"; //[[Ljava.lang.Strings 
	 	System.out.println(a);
	} 
}