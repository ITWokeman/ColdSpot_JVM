package test;

public class StrJoinTest{//字符串拼接
	public static void main(String arg[]){
		String a="Hello,"+2020+" year!";
		System.out.println(a);
	}
}