package test;

public class StringBufferTest{
	public static void main(String[] args) {
		StringBuffer s=new StringBuffer("Hello");
		System.out.println(s);
		s.append(",World");//追加字符
		System.out.println(s);

		s.delete(0,6);//删除
		System.out.println(s);

		s.insert(0,"Java ");//插入
		System.out.println(s);

		s.reverse();//反转
		System.out.println(s);
	}
}