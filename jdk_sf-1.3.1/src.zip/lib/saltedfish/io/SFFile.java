package saltedfish.io;

/**
@author 黄峰源
文件操作
**/
public class SFFile{

	/**
	通过SF_JVM读取文件内容，返回char数组
	仅支持ascll码
	**/
	private native char[] readFileBytes(String filepath);

	/**
	通过SF_JVM写入文件内容，返回true或false
	仅支持ascll码
	**/
	private native boolean writeFileBytes(String filepath,char[] bytes);

	/**
	通过SF_JVM创建目录。
	路径不得含有中文！
	**/
	private native void createFile(String filepath);


	//文件的内容
	private char[] fileBytes;

	//文件内容的长度
	private int fileBytesNum;

	//文件路径
	private String filepath;

	public SFFile(String filepath){
		fileBytes = readFileBytes(filepath);
		this.filepath = filepath;
		fileBytes = readFileBytes(this.filepath);
		fileBytesNum = fileBytes.length;
	}

	private void fileReader(){
		fileBytes = readFileBytes(this.filepath);
		if(fileBytes==null){
			System.out.println("file not find!");
		}
		fileBytesNum = fileBytes.length;
	}



	public void read(char[] context,int start,int end){
		fileReader();
		if(start<0 || end<0 || start<end){
			System.out.println("index wrong");
		}
		int index = 0,len=context.length;
		while(index<end && index<len){
			context[index] = fileBytes[index++];
		}
	}

	public char[] read(){
		fileReader();
		char[] context = new char[fileBytesNum];
		read(context,0,fileBytesNum);
		return context;
	}

	public void read(char[] context){
		fileReader();
		read(context,0,context.length);
	}

	public boolean exists(){
		if(fileBytes==null){
			return false;
		}
		return true;
	}

	public boolean write(char[] writeBytes){
		return writeFileBytes(this.filepath,writeBytes);
	}

}