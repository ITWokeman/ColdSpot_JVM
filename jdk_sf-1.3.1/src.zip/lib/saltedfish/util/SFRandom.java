package saltedfish.util;

/**
@author 黄峰源
java.util.Rondom类的替代品，用于获取随机数
**/
public class SFRandom{

	/**
	通过SF虚拟机的本地方法，获取随机整数
	**/
	public native int[] getRondomInts(int randomNum); 

	/**
	通过SF虚拟机的本地方法，获取随机整数
	**/
	public native long[] getRondomLongs(int randomNum); 

	public int nextInt(){
		return getRondomInts(1)[0];
	}

	public long nextLong(){
		return getRondomLongs(1)[0];
	}

	public float nextFloat(){
		int[] randoms = getRondomInts(2);
		return (float)randoms[0]/(float)randoms[1];
	}

	public int[] nextInts(int randomNum){
		return getRondomInts(randomNum);
	}

	public long[] nextLongs(int randomNum){
		return getRondomLongs(randomNum);
	}

	public float[] nextFloats(int randomNum){
		int[] randoms = getRondomInts(randomNum*2);
		float[] floats = new float[randomNum];
		for(int i=0;i<randomNum*2;i+=2){
			floats[i] = (float)randoms[i] / (float)(randoms[i+1]+1);
		}
		return floats;
	}
}